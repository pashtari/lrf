This repo provides PyTorch implementation of low-rank factorization (LRF) methods for data compression. This also includes the official implementation of "Quantization-free Image Compression Using Integer Matrix Factorization".

## Introduction

**LRF for Image Compression** ...


## Installation

First make sure that you have already installed [PyTorch](https://pytorch.org/get-started/locally/) since the details on how to do this depend on whether you have a CPU, GPU, etc. Then, clone the repository and install the requirements.
