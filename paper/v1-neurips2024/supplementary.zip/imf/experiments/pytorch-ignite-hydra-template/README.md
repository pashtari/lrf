This repo is a PyTorch template based on ignite and hydra.


## Installation

First make sure that you have already installed [PyTorch](https://pytorch.org/get-started/locally/) since the details on how to do this depend on whether you have a CPU, GPU, etc. Then, clone the repository and install the requirements:

```bash
$ pip install -r requirements.txt
```


## To-do
- 

## Contact

This repo is currently maintained by Pooya Ashtari ([@pashtari](https://github.com/pashtari)) and Pourya Behmandpoor ([@pourya-b](https://github.com/pourya-b)).